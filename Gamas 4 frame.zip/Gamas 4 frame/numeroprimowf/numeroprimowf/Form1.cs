﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace numeroprimowf
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            listBoxPrimos.Items.Clear();

            for (int i = 2; i <= 1000; i++)
            {
                if (EsPrimo(i))
                {
                    listBoxPrimos.Items.Add(i);
                }
            }
        }

        private bool EsPrimo(int numero)
        {
            if (numero <= 1)
                return false;
            if (numero == 2)
                return true;
            if (numero % 2 == 0)
                return false;

            int limite = (int)Math.Floor(Math.Sqrt(numero));

            for (int i = 3; i <= limite; i += 2)
            {
                if (numero % i == 0)
                    return false;
            }

            return true;
        }
    }
}
